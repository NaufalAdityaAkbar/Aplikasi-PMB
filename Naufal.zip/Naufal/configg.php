<?php
    define('DB_NAME', 'dbs_pmkb');
    define('DB_USER', 'root');
    define('DB_PASSWORD', '');
    define('DB_HOST', 'localhost');

    $kon = mysqli_connect("localhost", "root", "", "dbs_pmkb") or die(mysqli_error());
?>
