<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-With, x-xsrf-token");
header("Content-Type: application/json; charset=utf-8");

include "configg.php";
$data = array();

// Check if required parameters are set in the request
if(isset($_POST['username']) && isset($_POST['password'])) {
    // Sanitize and get the username and password values
    $username = mysqli_real_escape_string($kon, $_POST['username']);
    $password = mysqli_real_escape_string($kon, $_POST['password']);

    // Hash the password (you should use a stronger hashing algorithm in production)
    $hashedPassword = md5($password);

    // Use the username and hashed password in the SQL query
    $query = mysqli_query($kon, "SELECT * FROM tbl_user WHERE username = '$username' AND username = '$password'");
    
    if(mysqli_num_rows($query) > 0){
        // User credentials are valid
        $result = json_encode(array('success' => true, 'message' => 'Login successful'));
    } else {
        // User credentials are invalid
        $result = json_encode(array('success' => false, 'message' => 'Invalid username or password'));
    }
} else {
    // Handle case when required parameters are not set
    $result = json_encode(array('success' => false, 'message' => 'Username or password is missing'));
}

echo $result;
?>
