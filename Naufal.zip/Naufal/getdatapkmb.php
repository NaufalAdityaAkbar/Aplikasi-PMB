<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-With, x-xsrf-token");
header("Content-Type: application/json; charset=utf-8");

include "configg.php";

// Pastikan menggunakan isset() untuk memastikan variabel POST terdefinisi
$nama = isset($_POST['nama']) ? $_POST['nama'] : '';
$jenis_kelamin = isset($_POST['jenis_kelamin']) ? $_POST['jenis_kelamin'] : '';
$no_hp = isset($_POST['no_hp']) ? $_POST['no_hp'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$asal_sklh = isset($_POST['asal_sklh']) ? $_POST['asal_sklh'] : '';
$programstudi = isset($_POST['programstudi']) ? $_POST['programstudi'] : '';
$jenjang = isset($_POST['jenjang']) ? $_POST['jenjang'] : '';
$kelas = isset($_POST['kelas']) ? $_POST['kelas'] : '';
$infokampus = isset($_POST['infokampus']) ? $_POST['infokampus'] : '';

// Query INSERT
$insert = mysqli_query($kon, "INSERT INTO tbl_pendaftar (`kd`, `nama`, `jenis_kelamin`, `no_hp`, `email`, `asal_sklh`, `programstudi`, `jenjang`, `kelas`, `infokampus`, `regid`, `password`, `status`)
            VALUES (
            '',
            '$nama',
            '$jenis_kelamin',
            '$no_hp',
            '$email',
            '$asal_sklh',
            '$programstudi',
            '$jenjang',
            '$kelas',
            '$infokampus',
            '',
            '',
            '')");

// Cek apakah query berhasil
if ($insert) {
    $result = json_encode(array('success' => true, 'result' => $data));
} else {
    $result = json_encode(array('success' => false));
}

echo $result;
?>
